let section = document.getElementById('home-page');

export function showHome(context) {
    context.showSection(section);
} 